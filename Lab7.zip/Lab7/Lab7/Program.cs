﻿//Lab7
//CIS 199-03
//Due: 4/10/2022
//By: S2230 

//This program allows the user to enter a positive integer representing the number of stars per side desired
//Using a void method
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
