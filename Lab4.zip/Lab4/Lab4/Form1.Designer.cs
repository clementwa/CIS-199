﻿namespace Lab4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EnterGPA = new System.Windows.Forms.Label();
            this.EnterScore = new System.Windows.Forms.Label();
            this.AcceptTot = new System.Windows.Forms.Label();
            this.GpaTxt = new System.Windows.Forms.TextBox();
            this.ScoreTxt = new System.Windows.Forms.TextBox();
            this.acceptLbl = new System.Windows.Forms.Label();
            this.submitBtn = new System.Windows.Forms.Button();
            this.RejTot = new System.Windows.Forms.Label();
            this.rejLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // EnterGPA
            // 
            this.EnterGPA.AutoSize = true;
            this.EnterGPA.Location = new System.Drawing.Point(137, 73);
            this.EnterGPA.Name = "EnterGPA";
            this.EnterGPA.Size = new System.Drawing.Size(75, 16);
            this.EnterGPA.TabIndex = 0;
            this.EnterGPA.Text = "Enter GPA: ";
            // 
            // EnterScore
            // 
            this.EnterScore.AutoSize = true;
            this.EnterScore.Location = new System.Drawing.Point(137, 113);
            this.EnterScore.Name = "EnterScore";
            this.EnterScore.Size = new System.Drawing.Size(110, 16);
            this.EnterScore.TabIndex = 1;
            this.EnterScore.Text = "Enter Test Score:";
            // 
            // AcceptTot
            // 
            this.AcceptTot.AutoSize = true;
            this.AcceptTot.Location = new System.Drawing.Point(137, 183);
            this.AcceptTot.Name = "AcceptTot";
            this.AcceptTot.Size = new System.Drawing.Size(131, 16);
            this.AcceptTot.TabIndex = 2;
            this.AcceptTot.Text = "Applicants Accepted";
            // 
            // GpaTxt
            // 
            this.GpaTxt.Location = new System.Drawing.Point(301, 70);
            this.GpaTxt.Name = "GpaTxt";
            this.GpaTxt.Size = new System.Drawing.Size(100, 22);
            this.GpaTxt.TabIndex = 3;
            // 
            // ScoreTxt
            // 
            this.ScoreTxt.Location = new System.Drawing.Point(301, 110);
            this.ScoreTxt.Name = "ScoreTxt";
            this.ScoreTxt.Size = new System.Drawing.Size(100, 22);
            this.ScoreTxt.TabIndex = 4;
            // 
            // acceptLbl
            // 
            this.acceptLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.acceptLbl.Location = new System.Drawing.Point(301, 182);
            this.acceptLbl.Name = "acceptLbl";
            this.acceptLbl.Size = new System.Drawing.Size(100, 23);
            this.acceptLbl.TabIndex = 5;
            // 
            // submitBtn
            // 
            this.submitBtn.Location = new System.Drawing.Point(245, 308);
            this.submitBtn.Name = "submitBtn";
            this.submitBtn.Size = new System.Drawing.Size(75, 23);
            this.submitBtn.TabIndex = 6;
            this.submitBtn.Text = "Submit";
            this.submitBtn.UseVisualStyleBackColor = true;
            this.submitBtn.Click += new System.EventHandler(this.submitBtn_Click);
            // 
            // RejTot
            // 
            this.RejTot.AutoSize = true;
            this.RejTot.Location = new System.Drawing.Point(137, 223);
            this.RejTot.Name = "RejTot";
            this.RejTot.Size = new System.Drawing.Size(128, 16);
            this.RejTot.TabIndex = 7;
            this.RejTot.Text = "Applicants Rejected";
            // 
            // rejLbl
            // 
            this.rejLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rejLbl.Location = new System.Drawing.Point(301, 222);
            this.rejLbl.Name = "rejLbl";
            this.rejLbl.Size = new System.Drawing.Size(100, 23);
            this.rejLbl.TabIndex = 8;
            // 
            // Form1
            // 
            this.AcceptButton = this.submitBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rejLbl);
            this.Controls.Add(this.RejTot);
            this.Controls.Add(this.submitBtn);
            this.Controls.Add(this.acceptLbl);
            this.Controls.Add(this.ScoreTxt);
            this.Controls.Add(this.GpaTxt);
            this.Controls.Add(this.AcceptTot);
            this.Controls.Add(this.EnterScore);
            this.Controls.Add(this.EnterGPA);
            this.Name = "Form1";
            this.Text = "Lab 4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label EnterGPA;
        private System.Windows.Forms.Label EnterScore;
        private System.Windows.Forms.Label AcceptTot;
        private System.Windows.Forms.TextBox GpaTxt;
        private System.Windows.Forms.TextBox ScoreTxt;
        private System.Windows.Forms.Label acceptLbl;
        private System.Windows.Forms.Button submitBtn;
        private System.Windows.Forms.Label RejTot;
        private System.Windows.Forms.Label rejLbl;
    }
}

