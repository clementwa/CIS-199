﻿// Lab 4
// CIS 199-03
// Due: 2/27/2022
// By: S2230

// This program uses a GUI application to display admission decision based on entered GPA and Test Score
// This program also keeps count of the total accepted and rejected applicants

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class Form1 : Form
    {
       
        public Form1()
        {
            InitializeComponent();
        }

        private void submitBtn_Click(object sender, EventArgs e)
        {
            float GPA; //Declaring GPA variable
            float score; //Delaring Test Score variable
            int AcceptTot = 0; // Accepted Applicants count tracker
            int RejTot = 0; // Rejected Applicants count tracker

            if (float.TryParse(GpaTxt.Text, out GPA) && (float.TryParse(ScoreTxt.Text, out score))) //if statement that runs TryParse
            {
                if ((GPA >= 0.0 && GPA <= 4.0) && (score >= 0 && score <= 100)) //If statement for GPA parameters
                {
                    if ((GPA >= 3.0 && score >= 60 || (GPA > 3.0 && score >= 80))) //If statement for GPA required
                    {
                        MessageBox.Show("Accepted"); //Message displayed for accepted applicants
                        AcceptTot++; //Adds 1 to accepted applicants count
                        this.acceptLbl.Text = AcceptTot.ToString(); //converting to accept count to string
                    }
                    else
                    {
                        MessageBox.Show("Rejected"); //Message displayed for rejected Applicants
                        RejTot++; //Adds 1 to rejected applicants count
                        this.rejLbl.Text = RejTot.ToString(); //converting reject count to string
                    }  
                        
                }
                else
                    MessageBox.Show("Enter valid number"); //Message displayed for invalid inputs
            }
           
        }
    }
}
