﻿namespace Lab2
{
    partial class Title
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.firstNumTxt = new System.Windows.Forms.Label();
            this.secondNumTxt = new System.Windows.Forms.Label();
            this.ThirdNumTxt = new System.Windows.Forms.Label();
            this.outputLbl1 = new System.Windows.Forms.Label();
            this.outputLbl2 = new System.Windows.Forms.Label();
            this.outputLbl3 = new System.Windows.Forms.Label();
            this.calculateBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(229, 63);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 0;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(82, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Enter price of meal:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // firstNumTxt
            // 
            this.firstNumTxt.AutoSize = true;
            this.firstNumTxt.Location = new System.Drawing.Point(164, 132);
            this.firstNumTxt.Name = "firstNumTxt";
            this.firstNumTxt.Size = new System.Drawing.Size(36, 16);
            this.firstNumTxt.TabIndex = 3;
            this.firstNumTxt.Text = "15 %";
            this.firstNumTxt.Click += new System.EventHandler(this.label2_Click);
            // 
            // secondNumTxt
            // 
            this.secondNumTxt.AutoSize = true;
            this.secondNumTxt.Location = new System.Drawing.Point(164, 199);
            this.secondNumTxt.Name = "secondNumTxt";
            this.secondNumTxt.Size = new System.Drawing.Size(36, 16);
            this.secondNumTxt.TabIndex = 4;
            this.secondNumTxt.Text = "18 %";
            // 
            // ThirdNumTxt
            // 
            this.ThirdNumTxt.AutoSize = true;
            this.ThirdNumTxt.Location = new System.Drawing.Point(164, 273);
            this.ThirdNumTxt.Name = "ThirdNumTxt";
            this.ThirdNumTxt.Size = new System.Drawing.Size(36, 16);
            this.ThirdNumTxt.TabIndex = 7;
            this.ThirdNumTxt.Text = "20 %";
            // 
            // outputLbl1
            // 
            this.outputLbl1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLbl1.Location = new System.Drawing.Point(229, 131);
            this.outputLbl1.Name = "outputLbl1";
            this.outputLbl1.Size = new System.Drawing.Size(100, 23);
            this.outputLbl1.TabIndex = 8;
            // 
            // outputLbl2
            // 
            this.outputLbl2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLbl2.Location = new System.Drawing.Point(229, 198);
            this.outputLbl2.Name = "outputLbl2";
            this.outputLbl2.Size = new System.Drawing.Size(100, 23);
            this.outputLbl2.TabIndex = 9;
            // 
            // outputLbl3
            // 
            this.outputLbl3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLbl3.Location = new System.Drawing.Point(229, 272);
            this.outputLbl3.Name = "outputLbl3";
            this.outputLbl3.Size = new System.Drawing.Size(100, 23);
            this.outputLbl3.TabIndex = 10;
            // 
            // calculateBtn
            // 
            this.calculateBtn.Location = new System.Drawing.Point(167, 345);
            this.calculateBtn.Name = "calculateBtn";
            this.calculateBtn.Size = new System.Drawing.Size(103, 23);
            this.calculateBtn.TabIndex = 11;
            this.calculateBtn.Text = "Calculate Tip";
            this.calculateBtn.UseVisualStyleBackColor = true;
            this.calculateBtn.Click += new System.EventHandler(this.calculateBtn_Click);
            // 
            // Title
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.calculateBtn);
            this.Controls.Add(this.outputLbl3);
            this.Controls.Add(this.outputLbl2);
            this.Controls.Add(this.outputLbl1);
            this.Controls.Add(this.ThirdNumTxt);
            this.Controls.Add(this.secondNumTxt);
            this.Controls.Add(this.firstNumTxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Name = "Title";
            this.Text = "Lab 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label firstNumTxt;
        private System.Windows.Forms.Label secondNumTxt;
        private System.Windows.Forms.Label ThirdNumTxt;
        private System.Windows.Forms.Label outputLbl1;
        private System.Windows.Forms.Label outputLbl2;
        private System.Windows.Forms.Label outputLbl3;
        private System.Windows.Forms.Button calculateBtn;
    }
}

