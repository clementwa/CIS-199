﻿//Lab1
//CIS 199-03
//Due: 1/23/2022
//By: S2230 

//This program displays student S2230's,
//hobbies, favorite book, and movie to the console

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Grading ID: S2230"); //this is my Grading ID 
            Console.WriteLine("Hobbies: Working out, listen to music, read, and play piano"); 
            Console.WriteLine("Favorite Book: The Alchemist"); 
            Console.WriteLine("Favorite Movie: Avengers Infinity War");
        }
    }
}
