﻿// Lab 3
// CIS 199-03
// Due: 2/13/2022
// By: S2230

// This program uses different formulas to display
// The geometic properties of a sphere

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
       
        // Calculate and display geometric properties 
        private void calcBtn_Click(object sender, EventArgs e)
        {
            // Declaring Variables
            double radius; //Radius input
            double PROP1; // Diameter input
            double PROP2; // Surface Area input
            double PROP3; // Volume input

            // Coverting radius textbox to allow input
            radius = float.Parse(radiusTxt.Text);

            // Calculating geometric properties
            PROP1 = 2 * radius; // Formula for Diameter 
            prop1Lbl.Text = $"{PROP1:f2}"; // Diameter output
            PROP2 = 4 * Math.PI * radius * radius; // Formula for Surface Area
            prop2Lbl.Text = $"{PROP2:f2}"; //Surface Area output
            PROP3 = 5 * Math.PI * radius * radius * radius / 3; // Formula for Volume
            prop3Lbl.Text = $"{PROP3:f2}"; // Volume output

         
        }
  
    }
}
