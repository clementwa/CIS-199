﻿namespace Lab_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.sphereBox1 = new System.Windows.Forms.PictureBox();
            this.EnterRadius = new System.Windows.Forms.Label();
            this.radiusTxt = new System.Windows.Forms.TextBox();
            this.calcBtn = new System.Windows.Forms.Button();
            this.PROP1 = new System.Windows.Forms.Label();
            this.PROP2 = new System.Windows.Forms.Label();
            this.prop1Lbl = new System.Windows.Forms.Label();
            this.prop2Lbl = new System.Windows.Forms.Label();
            this.PROP3 = new System.Windows.Forms.Label();
            this.prop3Lbl = new System.Windows.Forms.Label();
            this.sphereBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.sphereBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sphereBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // sphereBox1
            // 
            this.sphereBox1.Image = ((System.Drawing.Image)(resources.GetObject("sphereBox1.Image")));
            this.sphereBox1.Location = new System.Drawing.Point(12, 12);
            this.sphereBox1.Name = "sphereBox1";
            this.sphereBox1.Size = new System.Drawing.Size(150, 150);
            this.sphereBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.sphereBox1.TabIndex = 0;
            this.sphereBox1.TabStop = false;
            // 
            // EnterRadius
            // 
            this.EnterRadius.AutoSize = true;
            this.EnterRadius.Location = new System.Drawing.Point(152, 62);
            this.EnterRadius.Name = "EnterRadius";
            this.EnterRadius.Size = new System.Drawing.Size(112, 16);
            this.EnterRadius.TabIndex = 1;
            this.EnterRadius.Text = "Radius of sphere:";
            // 
            // radiusTxt
            // 
            this.radiusTxt.Location = new System.Drawing.Point(270, 59);
            this.radiusTxt.Name = "radiusTxt";
            this.radiusTxt.Size = new System.Drawing.Size(100, 22);
            this.radiusTxt.TabIndex = 2;
            // 
            // calcBtn
            // 
            this.calcBtn.Location = new System.Drawing.Point(280, 98);
            this.calcBtn.Name = "calcBtn";
            this.calcBtn.Size = new System.Drawing.Size(81, 23);
            this.calcBtn.TabIndex = 3;
            this.calcBtn.Text = "Calculate";
            this.calcBtn.UseVisualStyleBackColor = true;
            this.calcBtn.Click += new System.EventHandler(this.calcBtn_Click);
            // 
            // PROP1
            // 
            this.PROP1.AutoSize = true;
            this.PROP1.Location = new System.Drawing.Point(32, 203);
            this.PROP1.Name = "PROP1";
            this.PROP1.Size = new System.Drawing.Size(62, 16);
            this.PROP1.TabIndex = 4;
            this.PROP1.Text = "Diameter";
            // 
            // PROP2
            // 
            this.PROP2.AutoSize = true;
            this.PROP2.Location = new System.Drawing.Point(9, 249);
            this.PROP2.Name = "PROP2";
            this.PROP2.Size = new System.Drawing.Size(85, 16);
            this.PROP2.TabIndex = 5;
            this.PROP2.Text = "Surface Area";
            // 
            // prop1Lbl
            // 
            this.prop1Lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.prop1Lbl.Location = new System.Drawing.Point(103, 202);
            this.prop1Lbl.Name = "prop1Lbl";
            this.prop1Lbl.Size = new System.Drawing.Size(100, 23);
            this.prop1Lbl.TabIndex = 6;
            // 
            // prop2Lbl
            // 
            this.prop2Lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.prop2Lbl.Location = new System.Drawing.Point(103, 248);
            this.prop2Lbl.Name = "prop2Lbl";
            this.prop2Lbl.Size = new System.Drawing.Size(100, 23);
            this.prop2Lbl.TabIndex = 7;
            // 
            // PROP3
            // 
            this.PROP3.AutoSize = true;
            this.PROP3.Location = new System.Drawing.Point(41, 295);
            this.PROP3.Name = "PROP3";
            this.PROP3.Size = new System.Drawing.Size(53, 16);
            this.PROP3.TabIndex = 8;
            this.PROP3.Text = "Volume";
            // 
            // prop3Lbl
            // 
            this.prop3Lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.prop3Lbl.Location = new System.Drawing.Point(103, 294);
            this.prop3Lbl.Name = "prop3Lbl";
            this.prop3Lbl.Size = new System.Drawing.Size(100, 23);
            this.prop3Lbl.TabIndex = 9;
            // 
            // sphereBox2
            // 
            this.sphereBox2.Image = ((System.Drawing.Image)(resources.GetObject("sphereBox2.Image")));
            this.sphereBox2.Location = new System.Drawing.Point(224, 191);
            this.sphereBox2.Name = "sphereBox2";
            this.sphereBox2.Size = new System.Drawing.Size(150, 150);
            this.sphereBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.sphereBox2.TabIndex = 10;
            this.sphereBox2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(382, 353);
            this.Controls.Add(this.sphereBox2);
            this.Controls.Add(this.prop3Lbl);
            this.Controls.Add(this.PROP3);
            this.Controls.Add(this.prop2Lbl);
            this.Controls.Add(this.prop1Lbl);
            this.Controls.Add(this.PROP2);
            this.Controls.Add(this.PROP1);
            this.Controls.Add(this.calcBtn);
            this.Controls.Add(this.radiusTxt);
            this.Controls.Add(this.EnterRadius);
            this.Controls.Add(this.sphereBox1);
            this.Name = "Form1";
            this.Text = "Lab 3";
            ((System.ComponentModel.ISupportInitialize)(this.sphereBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sphereBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox sphereBox1;
        private System.Windows.Forms.Label EnterRadius;
        private System.Windows.Forms.TextBox radiusTxt;
        private System.Windows.Forms.Button calcBtn;
        private System.Windows.Forms.Label PROP1;
        private System.Windows.Forms.Label PROP2;
        private System.Windows.Forms.Label prop1Lbl;
        private System.Windows.Forms.Label prop2Lbl;
        private System.Windows.Forms.Label PROP3;
        private System.Windows.Forms.Label prop3Lbl;
        private System.Windows.Forms.PictureBox sphereBox2;
    }
}

