﻿// Program 4
// CIS 199-03
// Due: 4/21/2022
// By: S2230 

// This program creates a reusable class and separate console application that creates a list of objects
// Uses valid input to displau information about selected Superheros

using System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
    class Program
    {
        public static void Main(string[] args)
        {
          //Superhero hero information inputed into class objects
          Superhero hero1 = new Superhero("Black Panther", "Wakanda", "Heighten strength, speed, stamina, and reflexes", 1997, "Master of Martial Arts", 'A', true);
          Superhero hero2 = new Superhero("Flash", "Central City", "Superhuman speed", 1992, "Phase through solid objects", 'F', false);
          Superhero hero3 = new Superhero("Spider-Man", "New York", "Spider senses", 2001, "Superhuman reflexes", 'S', true);

          Console.WriteLine("Original list of super heros"); //Program print heading
          Console.WriteLine("----------------------"); //dashes for aesthethic reasons
          
            //initializing array
            Superhero[] hero = new Superhero[3];

            //Array assignments
            hero[0] = hero1;
            hero[1] = hero2;
            hero[2] = hero3;

            foreach (Superhero item in hero)
            {
                Console.WriteLine($"{item}");
                Console.WriteLine();
            }
        }
    }
}
