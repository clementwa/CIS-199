﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
    class Superhero
    {   
        public string _NAME; //variable for superhero name
        public string BIRTH_CITY; //variable for superhero city of birh
        public string FIRST_POWER; //variable for superhero first power
        public int BIRTH_YEAR; //variable for superhero birth year
        public string SECOND_POWER; //vairable for superhero second power
        public bool _onPlanetEarth; //variable to determine if superhero is on earth
  
        //Superhero constructor 
        public Superhero(string name, string birthCity, string firstPower, int birthYear, string secondPower, char initial, bool onPlantEarth)
        {
            Name = name;
            BirthCity = birthCity;
            FirstPower = firstPower;
            BirthYear = birthYear;
            SecondPower = secondPower;
            _onPlanetEarth = onPlantEarth;

        }
        public string Name
        {
            get { return _NAME; } //returning name as a string

            set { _NAME = value; } //setting name to the value

        }
        public string BirthCity
        {
            get { return BIRTH_CITY; } //returning birth city as a string

            set { BIRTH_CITY = value; } //setting birth city to the value 
        }
        public string FirstPower
        {
            get { return FIRST_POWER; } //returning first power as a string

            set { FIRST_POWER = value; } //setting first power to the value
        }
        public int BirthYear
        {
            get { return BIRTH_YEAR; } //returning birth year as integer

            set
            {
               if (value > 0) //if value is greater than zero
                {
                    BIRTH_YEAR = value; //birth year will be set to the value
                }
               else //if value is not greater than zero
                {
                    BIRTH_YEAR = 1999; //birth year will be set to 1999
                }
            }
        }
        public string SecondPower
        {
            get { return SECOND_POWER; } //returning second power as a string 

            set { SECOND_POWER = value; } //birth year will be set to the value
        }
   

        public char Initial
        {
            get { return _NAME[0]; } //setting the first character of name as return value
        }

        public void OnPlantEarth()
        {
            _onPlanetEarth = true; //setting bool to true
        }

        public void OffPlantEarth()
        {
            _onPlanetEarth= false; //setting bool to false  
        }

        public bool IsOnPlanetEarth()
        {
            return _onPlanetEarth; //setting bool as return value for the method 
        }

        public override string ToString() //converting to string to display output when ran
        {
            return $"Name: {Name}{Environment.NewLine}" + $"City: {BirthCity}{Environment.NewLine}" + $"First Super Power: {FirstPower}{Environment.NewLine}" + $"Born in: {BirthYear}{Environment.NewLine}" + $"Plant Earth: {IsOnPlanetEarth()}{Environment.NewLine}" + $"Initial: {Initial}{Environment.NewLine}";
          
        }
    }

}
